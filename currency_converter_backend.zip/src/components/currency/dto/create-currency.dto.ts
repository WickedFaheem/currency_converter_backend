export class CreateCurrencyDto {}



