export class Currency {}
