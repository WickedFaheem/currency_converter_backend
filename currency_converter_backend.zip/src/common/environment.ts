export const environment = {
    production: false,
    version: '0.0.0',
    apiUrl: 'https://api.freecurrencyapi.com/v1/',
    API_KEY: '4E0VK7BnkdeUuh1vegAt808v2IUjzUR6lxcvBMT2',
};